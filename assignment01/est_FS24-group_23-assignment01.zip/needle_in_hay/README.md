# Problem: Find the Index of the First Occurence in a String

## Description

Given two strings needle and haystack, return the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.
If any string is null, return -1. If both strings are empty, return 0.
### Example 1:

**Input**: `haystack = "sadbutsad", needle = "sad"`
**Output**: `0`

### Example 2:

**Input**: `haystack = "computerscience", needle = "cs"`
**Output**: `-1`
package zest;

public class DatabaseConnection {
    public void close() {
        System.out.println("Database connection closed.");
    }
}

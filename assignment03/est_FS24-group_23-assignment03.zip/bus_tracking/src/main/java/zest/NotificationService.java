package zest;

public interface NotificationService {
    void notifyPassengers(String busId, String message);
}

package zest;

public interface GPSDeviceService {
    Location getCurrentLocation(String busId);
}

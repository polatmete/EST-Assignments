package zest;


public interface MapService {
    void updateMap(String busId, Location location);
}

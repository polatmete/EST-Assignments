package zest;

enum TicketPriority {
    NORMAL,
    URGENT
}

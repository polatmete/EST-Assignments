package zest;

// Notification service interface
public interface NotificationService {
    void notifyCustomer(String customerEmail, String message);
}

package zest;

// Logging service interface
public interface LogService {
    void logTicketCreation(Ticket ticket);
}

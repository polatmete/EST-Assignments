package zest;

// Repository interface for Ticket data access
public interface TicketRepository {
    void save(Ticket ticket);
}

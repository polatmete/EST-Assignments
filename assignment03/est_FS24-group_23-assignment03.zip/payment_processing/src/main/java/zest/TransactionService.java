package zest;

public interface TransactionService {
    void processTransaction(Transaction transaction);
}

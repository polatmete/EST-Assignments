package zest;

public class Transaction {
    private int id;

    public Transaction (int id) {
        this.id = id;
    }

    public int getId () {
        return this.id;
    }
}

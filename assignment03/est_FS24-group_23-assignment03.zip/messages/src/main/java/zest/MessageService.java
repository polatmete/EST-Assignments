package zest;

public class MessageService {
    public void sendMessage(String receiver, String message) {
        // Logic to send a message to a user would go here, e.g., through an API
        System.out.println("Message sent to " + receiver + ": " + message);
    }
}

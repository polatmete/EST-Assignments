package zest;

public interface MessageListener {
    void logSentMessage(String receiver, String content);
}

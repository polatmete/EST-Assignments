package zest;

public interface EventListener {
    void onOrderPlaced(Order order);
}

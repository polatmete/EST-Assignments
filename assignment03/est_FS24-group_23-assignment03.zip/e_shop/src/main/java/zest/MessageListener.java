package zest;

public interface MessageListener {
    void logSentMessage(String orderId, Double amount);
}
